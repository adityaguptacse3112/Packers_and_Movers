# Development guide

## How the site is put together

- `index.html` holds every section of the page, the SEO tags and the JSON-LD structured data.
- `css/styles.css` is the only stylesheet. Colours, fonts, radii and shadows are CSS custom properties in the `:root` block at the top.
- `js/script.js` is one self-contained script (an IIFE) with four jobs: footer year, mobile menu, scroll-reveal and the quote form.
- `assets/images/` holds all images. Paths in `index.html` are relative to the repository root.

There is no backend, so there is no `.env` file and no server code.

## Common edits

### Change the phone or WhatsApp number

Search the project for `7488764972` and replace it everywhere. It appears in:

- `index.html`: `tel:` links, `wa.me` links, the meta description, Open Graph description, structured data (`+917488764972`), FAQ text and visible text
- `js/script.js`: the `https://wa.me/917488764972` URL used by the quote form

### Add or change a service

1. Duplicate a `.service-card` inside `#services` in `index.html` and edit the icon, heading and text.
2. Add a matching `<option>` to the "Move Type" `<select>` in the quote form.
3. Update the services FAQ answer if it lists services.

### Change colours or fonts

Edit the custom properties at the top of `css/styles.css`. If you change fonts, also update the Google Fonts `<link>` in `index.html`.

### Replace images

Put new files in `assets/images/` and update the paths in `index.html`. Keep `width` and `height` attributes on `<img>` tags to avoid layout shift, and keep `loading="lazy"` on images below the first screen (the hero image stays eager).

## Quote form

The form is handled entirely in the browser. On submit, `js/script.js` checks that name, phone (at least 10 digits), pickup and destination are filled in, builds a text message, and opens `https://wa.me/917488764972?text=...` in a new tab. If you later add a real backend, replace the `window.open` call at the end of the submit handler.

## Local checks

No build or test tooling is configured. Useful quick checks:

```bash
# Syntax check for the script (requires Node.js)
node --check js/script.js

# Serve locally and click through the page, including the quote form and mobile menu
python3 -m http.server 8000
```

After moving or renaming any file, search for its old name in `index.html`, `css/styles.css` and `js/script.js` and confirm the browser's network tab shows no 404s.

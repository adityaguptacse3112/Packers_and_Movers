# Deployment

The site is static: there is nothing to build, so the publish directory is the repository root and `index.html` is the entry point.

## GitHub Pages

1. Push the repository to GitHub.
2. Open **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, select the `main` branch and the `/ (root)` folder, then save.
4. The site will be available at `https://<username>.github.io/<repository>/` after a minute or two. All asset paths in the project are relative, so they work under that sub-path.

## Netlify

Import the repository (or drag the folder into Netlify Drop). Leave the build command empty and set the publish directory to `.` (the root).

## Vercel

Import the repository, choose **Other** as the framework preset, leave the build command empty and keep the output directory as the root.

## Cloudflare Pages

Connect the repository, leave the build command empty and set the build output directory to `/`.

## After the first deploy

- Replace `https://www.kashipackersmovers.example/` in the `canonical` link and `og:url` tag in `index.html` with the real address.
- Open the live site on a phone and test the Call button, the WhatsApp button and the quote form.

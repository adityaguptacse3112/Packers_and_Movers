(function () {
  "use strict";

  /* Footer year */
  var yearEl = document.getElementById("year");
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  /* Mobile nav toggle */
  var navToggle = document.getElementById("navToggle");
  var primaryNav = document.getElementById("primaryNav");

  if (navToggle && primaryNav) {
    navToggle.addEventListener("click", function () {
      var isOpen = primaryNav.classList.toggle("open");
      navToggle.setAttribute("aria-expanded", String(isOpen));
      navToggle.setAttribute("aria-label", isOpen ? "Close menu" : "Open menu");
    });

    primaryNav.querySelectorAll("a").forEach(function (link) {
      link.addEventListener("click", function () {
        primaryNav.classList.remove("open");
        navToggle.setAttribute("aria-expanded", "false");
        navToggle.setAttribute("aria-label", "Open menu");
      });
    });
  }

  /* Shrink header on scroll */
  var header = document.querySelector(".site-header");
  if (header) {
    var onScroll = function () {
      header.classList.toggle("scrolled", window.scrollY > 12);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
  }

  /* Scroll reveal */
  var revealEls = document.querySelectorAll(".reveal");
  var prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  if (revealEls.length) {
    if (prefersReducedMotion || !("IntersectionObserver" in window)) {
      revealEls.forEach(function (el) { el.classList.add("in-view"); });
    } else {
      var observer = new IntersectionObserver(
        function (entries) {
          entries.forEach(function (entry) {
            if (entry.isIntersecting) {
              entry.target.classList.add("in-view");
              observer.unobserve(entry.target);
            }
          });
        },
        { threshold: 0.12, rootMargin: "0px 0px -40px 0px" }
      );
      revealEls.forEach(function (el) { observer.observe(el); });
    }
  }

  /* Quote form -> WhatsApp */
  var form = document.getElementById("quoteForm");
  if (form) {
    var requiredFields = ["name", "phone", "from", "to"];

    var showError = function (fieldName, message) {
      var input = form.elements[fieldName];
      if (!input) return;
      var wrapper = input.closest(".field");
      var errorEl = wrapper ? wrapper.querySelector(".field-error") : null;
      if (wrapper) wrapper.classList.toggle("invalid", Boolean(message));
      if (errorEl) errorEl.textContent = message || "";
    };

    form.addEventListener("submit", function (e) {
      e.preventDefault();

      var data = new FormData(form);
      var values = {};
      requiredFields.forEach(function (f) { values[f] = (data.get(f) || "").toString().trim(); });

      var isValid = true;

      if (!values.name) { showError("name", "Please enter your name."); isValid = false; }
      else { showError("name", ""); }

      var phoneDigits = values.phone.replace(/\D/g, "");
      if (!phoneDigits || phoneDigits.length < 10) { showError("phone", "Enter a valid 10-digit phone number."); isValid = false; }
      else { showError("phone", ""); }

      if (!values.from) { showError("from", "Please tell us the pickup location."); isValid = false; }
      else { showError("from", ""); }

      if (!values.to) { showError("to", "Please tell us the destination."); isValid = false; }
      else { showError("to", ""); }

      if (!isValid) {
        var firstInvalid = form.querySelector(".invalid input");
        if (firstInvalid) firstInvalid.focus();
        return;
      }

      var moveType = (data.get("moveType") || "Not specified").toString();
      var date = (data.get("date") || "").toString();
      var message = (data.get("message") || "").toString().trim();

      var lines = [
        "Hello Kashi Packers & Movers,",
        "I want a moving quote.",
        "",
        "Name: " + values.name,
        "Phone: " + values.phone,
        "Moving From: " + values.from,
        "Moving To: " + values.to,
        "Move Type: " + moveType,
        "Preferred Date: " + (date || "Not specified"),
        "Requirements: " + (message || "Not specified")
      ];

      var whatsappText = encodeURIComponent(lines.join("\n"));
      var whatsappUrl = "https://wa.me/917488764972?text=" + whatsappText;

      window.open(whatsappUrl, "_blank", "noopener");
    });
  }
})();

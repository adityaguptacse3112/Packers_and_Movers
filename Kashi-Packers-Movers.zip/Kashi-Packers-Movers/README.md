# Kashi Packers & Movers — Website

Responsive single-page website for **Kashi Packers & Movers**, a packing, shifting and transportation business based in Danapur, Bihar (owner: Sunny Kumar).

The site is plain HTML, CSS and JavaScript. There is no backend, database, build step or API key — everything runs from static files.

## Features

- Single-page layout: hero, service highlights, 12 services, quote form, how-it-works, about, why-choose-us, service area, FAQ and contact call-to-action
- Quote form that validates input in the browser and opens WhatsApp with the enquiry pre-filled (nothing is stored or sent to a server)
- Click-to-call and WhatsApp buttons, including floating action buttons
- Mobile navigation, sticky header, scroll-reveal animations
- SEO basics: meta description, Open Graph tags, `MovingCompany` structured data (JSON-LD)
- Accessibility: skip link, semantic landmarks, labelled form fields with inline errors, visible focus states, `prefers-reduced-motion` respected
- Responsive from phone to desktop

## Tech stack

| Layer   | Details                                                         |
| ------- | --------------------------------------------------------------- |
| Markup  | HTML5                                                           |
| Styling | CSS3 (custom properties, grid, flexbox) in one stylesheet       |
| Script  | Vanilla JavaScript, no libraries                                |
| Fonts   | Manrope and DM Sans from Google Fonts                           |
| Icons   | Inline SVG                                                      |
| Images  | JPEG, plus a WebP version of the skyline band and an SVG logo   |

## Project structure

```
Kashi-Packers-Movers/
├── index.html              Page markup, SEO tags and structured data
├── css/
│   └── styles.css          Design tokens, layout, components, responsive rules
├── js/
│   └── script.js           Mobile nav, scroll effects, form validation, WhatsApp message
├── assets/
│   └── images/
│       ├── hero-truck.jpg      Hero photo (also used as the header mark and favicon)
│       ├── skyline-band.jpg    Skyline divider (JPEG fallback)
│       ├── skyline-band.webp   Skyline divider (WebP, smaller)
│       └── logo.svg            Brand mark used in the footer
├── docs/
│   ├── development.md      Editing content, structure notes, local checks
│   └── deployment.md       Hosting options
├── .gitignore
└── README.md
```

The site lives at the repository root on purpose, so GitHub Pages, Netlify, Vercel and Cloudflare Pages can publish it without extra configuration.

## Run locally

Open `index.html` in a browser, or serve the folder:

```bash
python3 -m http.server 8000
# then visit http://localhost:8000
```

## Deploy

It is a static site, so any static host works. See [docs/deployment.md](docs/deployment.md) for GitHub Pages, Netlify, Vercel and Cloudflare Pages.

## Editing content

See [docs/development.md](docs/development.md). In short:

- **Phone / WhatsApp number**: `7488764972` appears in `index.html` (`tel:` and `wa.me` links, structured data) and in `js/script.js` (the WhatsApp URL for the form).
- **Services**: each one is a `.service-card` inside `#services`, and also an `<option>` in the quote form's "Move Type" list.
- **Colours and fonts**: CSS custom properties at the top of `css/styles.css`.

## Before going live

- Replace the placeholder domain `https://www.kashipackersmovers.example/` in the `canonical` link and `og:url` meta tag in `index.html` with the real website address.
- Optionally add an `og:image` (full URL) so shared links show a preview picture.

## Content note

The copy only states what the business has provided: the Danapur, Bihar base, the listed services, the contact number and the owner's name. If you add reviews, statistics or certifications later, keep them factual.

## License

No license has been chosen yet, so all rights are reserved by the business owner. Add a `LICENSE` file if you decide to publish this under an open-source license.
